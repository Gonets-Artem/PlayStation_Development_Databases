create view storageroom_sort(storage_room_id, location, capacity, plant_id) as
SELECT polls_storageroom.storage_room_id,
       polls_storageroom.location,
       polls_storageroom.capacity,
       polls_storageroom.plant_id
FROM polls_storageroom
ORDER BY polls_storageroom.capacity DESC, polls_storageroom.location;

alter table storageroom_sort
    owner to hseezkivmyedbs;

