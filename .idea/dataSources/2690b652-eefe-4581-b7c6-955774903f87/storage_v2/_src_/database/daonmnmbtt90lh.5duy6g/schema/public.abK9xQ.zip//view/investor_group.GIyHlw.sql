create view investor_group(advertising_department_id, count) as
SELECT polls_investor.advertising_department_id,
       count(polls_investor.name) AS count
FROM polls_investor
GROUP BY polls_investor.advertising_department_id
ORDER BY (count(polls_investor.name)) DESC, polls_investor.advertising_department_id;

alter table investor_group
    owner to hseezkivmyedbs;

