create view formfactor_group_form(form, avg_height, avg_weight, avg_depth, avg_width) as
SELECT polls_formfactor.form,
       round(avg(polls_formfactor.height)::numeric, 1) AS avg_height,
       round(avg(polls_formfactor.weight)::numeric, 1) AS avg_weight,
       round(avg(polls_formfactor.depth)::numeric, 1)  AS avg_depth,
       round(avg(polls_formfactor.width)::numeric, 1)  AS avg_width
FROM polls_formfactor
GROUP BY polls_formfactor.form
ORDER BY (round(avg(polls_formfactor.weight)::numeric, 1)) DESC;

alter table formfactor_group_form
    owner to hseezkivmyedbs;

