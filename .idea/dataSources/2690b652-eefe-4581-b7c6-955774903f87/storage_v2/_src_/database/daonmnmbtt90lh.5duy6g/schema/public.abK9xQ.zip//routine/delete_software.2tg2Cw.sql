create function delete_software() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_software_developers where software_id=old.software_id;
    delete from polls_prototype_softwares where software_id=old.software_id;
    return old;
end;
$$;

alter function delete_software() owner to hseezkivmyedbs;

