create view kit_dualshock(kit_id, name, date, console_id, dualshock_id) as
SELECT polls_kit.kit_id,
       polls_kit.name,
       polls_kit.date,
       polls_kit.console_id,
       polls_kit.dualshock_id
FROM polls_kit
WHERE polls_kit.dualshock_id IS NOT NULL
  AND polls_kit.psvr_id IS NULL
ORDER BY polls_kit.date;

alter table kit_dualshock
    owner to hseezkivmyedbs;

