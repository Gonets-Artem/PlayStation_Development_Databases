create view dualshock_sort_in
            (dualshock_id, country, connection_type, compatibility, weight, action_radius, battery_power) as
SELECT polls_dualshock.dualshock_id,
       polls_dualshock.country,
       polls_dualshock.connection_type,
       polls_dualshock.compatibility,
       polls_dualshock.weight,
       polls_dualshock.action_radius,
       polls_dualshock.battery_power
FROM polls_dualshock
WHERE polls_dualshock.country::text = ANY (ARRAY ['Germany'::character varying, 'Canada'::character varying]::text[])
ORDER BY polls_dualshock.action_radius DESC, polls_dualshock.battery_power DESC;

alter table dualshock_sort_in
    owner to hseezkivmyedbs;

