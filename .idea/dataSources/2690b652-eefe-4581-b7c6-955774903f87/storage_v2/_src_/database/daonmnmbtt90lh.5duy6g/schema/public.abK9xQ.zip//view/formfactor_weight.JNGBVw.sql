create view formfactor_weight(form_factor_id, name, form, weight, height, depth, width) as
SELECT polls_formfactor.form_factor_id,
       polls_formfactor.name,
       polls_formfactor.form,
       polls_formfactor.weight,
       polls_formfactor.height,
       polls_formfactor.depth,
       polls_formfactor.width
FROM polls_formfactor
ORDER BY polls_formfactor.weight DESC, polls_formfactor.name;

alter table formfactor_weight
    owner to hseezkivmyedbs;

