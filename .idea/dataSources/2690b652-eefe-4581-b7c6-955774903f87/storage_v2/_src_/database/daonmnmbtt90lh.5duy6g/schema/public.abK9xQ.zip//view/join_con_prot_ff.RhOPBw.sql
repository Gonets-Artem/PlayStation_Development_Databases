create view join_con_prot_ff
            (console_name, console_date, rom, ram, console_weight, prototype_name, prototype_date, type_storage_device,
             ssd_type, specifications, form, form_factor_name, height, depth, width)
as
SELECT polls_console.name   AS console_name,
       polls_console.date   AS console_date,
       polls_console.rom,
       polls_console.ram,
       polls_console.weight AS console_weight,
       ff_prot.prototype_name,
       ff_prot.date         AS prototype_date,
       ff_prot.type_storage_device,
       ff_prot.ssd_type,
       ff_prot.specifications,
       ff_prot.form,
       ff_prot.form_factor_name,
       ff_prot.height,
       ff_prot.depth,
       ff_prot.width
FROM polls_console
         JOIN (SELECT polls_prototype.name AS prototype_name,
                      polls_prototype.date,
                      polls_prototype.type_storage_device,
                      polls_prototype.ssd_type,
                      polls_prototype.specifications,
                      ff.form,
                      ff.name              AS form_factor_name,
                      ff.height,
                      ff.weight,
                      ff.depth,
                      ff.width,
                      polls_prototype.prototype_id
               FROM polls_prototype
                        JOIN (SELECT polls_formfactor.form,
                                     polls_formfactor.name,
                                     polls_formfactor.height,
                                     polls_formfactor.weight,
                                     polls_formfactor.depth,
                                     polls_formfactor.width,
                                     polls_prototype_form_factors.prototype_id
                              FROM polls_formfactor
                                       JOIN polls_prototype_form_factors ON polls_formfactor.form_factor_id =
                                                                            polls_prototype_form_factors.formfactor_id) ff
                             ON polls_prototype.prototype_id = ff.prototype_id) ff_prot
              ON polls_console.prototype_id = ff_prot.prototype_id;

alter table join_con_prot_ff
    owner to hseezkivmyedbs;

