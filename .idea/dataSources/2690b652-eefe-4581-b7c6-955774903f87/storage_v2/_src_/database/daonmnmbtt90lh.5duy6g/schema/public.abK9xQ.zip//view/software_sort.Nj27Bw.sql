create view software_sort(software_id, type, version, status) as
SELECT polls_software.software_id,
       polls_software.type,
       polls_software.version,
       polls_software.status
FROM polls_software
ORDER BY polls_software.status DESC, polls_software.type, polls_software.version DESC;

alter table software_sort
    owner to hseezkivmyedbs;

