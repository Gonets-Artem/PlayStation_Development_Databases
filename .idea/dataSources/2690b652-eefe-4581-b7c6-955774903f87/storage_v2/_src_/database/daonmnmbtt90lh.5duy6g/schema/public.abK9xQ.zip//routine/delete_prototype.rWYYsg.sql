create function delete_prototype() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_prototype_form_factors where prototype_id=old.prototype_id;
    return old;
end;
$$;

alter function delete_prototype() owner to hseezkivmyedbs;

