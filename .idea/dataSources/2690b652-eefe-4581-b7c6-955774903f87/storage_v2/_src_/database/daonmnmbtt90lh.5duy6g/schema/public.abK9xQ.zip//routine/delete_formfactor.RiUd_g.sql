create function delete_formfactor() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_prototype_form_factors where formfactor_id=old.form_factor_id;
    return old;
end;
$$;

alter function delete_formfactor() owner to hseezkivmyedbs;

