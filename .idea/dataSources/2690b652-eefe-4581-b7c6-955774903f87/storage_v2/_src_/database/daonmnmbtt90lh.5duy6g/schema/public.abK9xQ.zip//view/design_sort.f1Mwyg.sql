create view design_sort(design_id, name, colour, style, status) as
SELECT polls_design.design_id,
       polls_design.name,
       polls_design.colour,
       polls_design.style,
       polls_design.status
FROM polls_design
ORDER BY polls_design.status DESC, polls_design.name;

alter table design_sort
    owner to hseezkivmyedbs;

