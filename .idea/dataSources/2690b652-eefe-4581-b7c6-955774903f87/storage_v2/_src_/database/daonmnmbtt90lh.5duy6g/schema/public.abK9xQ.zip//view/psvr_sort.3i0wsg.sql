create view psvr_sort(ps_vr_id, country, type_display, diagonal, permission, viewing_angle) as
SELECT polls_psvr.ps_vr_id,
       polls_psvr.country,
       polls_psvr.type_display,
       polls_psvr.diagonal,
       polls_psvr.permission,
       polls_psvr.viewing_angle
FROM polls_psvr
ORDER BY polls_psvr.permission DESC, polls_psvr.diagonal DESC, polls_psvr.viewing_angle DESC;

alter table psvr_sort
    owner to hseezkivmyedbs;

