create view consoles_group_prot (prototype_id, count, min_rom, max_rom, min_weight, max_weight, min_ram, max_ram) as
SELECT polls_console.prototype_id,
       count(polls_console.console_id) AS count,
       min(polls_console.rom)          AS min_rom,
       max(polls_console.rom)          AS max_rom,
       min(polls_console.weight)       AS min_weight,
       max(polls_console.weight)       AS max_weight,
       min(polls_console.ram)          AS min_ram,
       max(polls_console.ram)          AS max_ram
FROM polls_console
GROUP BY polls_console.prototype_id
ORDER BY (count(polls_console.console_id)) DESC;

alter table consoles_group_prot
    owner to hseezkivmyedbs;

