create function delete_component() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_supplier_components where component_id=old.component_id;
    return old;
end;
$$;

alter function delete_component() owner to hseezkivmyedbs;

