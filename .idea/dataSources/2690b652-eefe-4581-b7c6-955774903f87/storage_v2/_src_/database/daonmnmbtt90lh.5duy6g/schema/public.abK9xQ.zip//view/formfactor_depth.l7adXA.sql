create view formfactor_depth(form_factor_id, name, form, depth, height, weight, width) as
SELECT polls_formfactor.form_factor_id,
       polls_formfactor.name,
       polls_formfactor.form,
       polls_formfactor.depth,
       polls_formfactor.height,
       polls_formfactor.weight,
       polls_formfactor.width
FROM polls_formfactor
ORDER BY polls_formfactor.depth DESC, polls_formfactor.name;

alter table formfactor_depth
    owner to hseezkivmyedbs;

