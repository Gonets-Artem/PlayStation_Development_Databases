create view formfactor_height(form_factor_id, name, form, height, weight, depth, width) as
SELECT polls_formfactor.form_factor_id,
       polls_formfactor.name,
       polls_formfactor.form,
       polls_formfactor.height,
       polls_formfactor.weight,
       polls_formfactor.depth,
       polls_formfactor.width
FROM polls_formfactor
ORDER BY polls_formfactor.height DESC, polls_formfactor.name;

alter table formfactor_height
    owner to hseezkivmyedbs;

