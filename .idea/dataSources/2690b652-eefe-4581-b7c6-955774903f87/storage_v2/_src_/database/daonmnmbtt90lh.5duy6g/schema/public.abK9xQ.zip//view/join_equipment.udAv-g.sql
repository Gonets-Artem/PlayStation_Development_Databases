create view join_equipment (plant_id, avg_temperature, avg_wear_level, avg_noise_level, avg_errors_number) as
SELECT polls_equipment.plant_id,
       round(avg(polls_equipmentcondition.temperature)::numeric, 2) AS avg_temperature,
       round(avg(polls_equipmentcondition.wear_level)::numeric, 2)  AS avg_wear_level,
       round(avg(polls_equipmentcondition.noise_level)::numeric, 2) AS avg_noise_level,
       round(avg(polls_equipmentcondition.errors_number), 2)        AS avg_errors_number
FROM polls_equipment
         JOIN polls_equipmentcondition ON polls_equipment.equipment_id = polls_equipmentcondition.equipment_id
GROUP BY polls_equipment.plant_id
ORDER BY polls_equipment.plant_id;

alter table join_equipment
    owner to hseezkivmyedbs;

