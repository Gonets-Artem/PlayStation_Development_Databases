create view join_supplier_compon(supplier_name, email, phone, component_name, description) as
SELECT sup.name             AS supplier_name,
       sup.email,
       sup.phone,
       polls_component.name AS component_name,
       polls_component.description
FROM polls_component
         JOIN (SELECT polls_supplier.supplier_id,
                      polls_supplier.name,
                      polls_supplier.email,
                      polls_supplier.phone,
                      polls_supplier_components.component_id
               FROM polls_supplier
                        JOIN polls_supplier_components
                             ON polls_supplier.supplier_id = polls_supplier_components.supplier_id) sup
              ON polls_component.component_id = sup.component_id
ORDER BY sup.name, polls_component.name;

alter table join_supplier_compon
    owner to hseezkivmyedbs;

