create view join_designer_des(designer_name, email, phone, role, design_name, colour, style, status) as
SELECT des.name          AS designer_name,
       des.email,
       des.phone,
       des.role,
       polls_design.name AS design_name,
       polls_design.colour,
       polls_design.style,
       polls_design.status
FROM polls_design
         JOIN (SELECT polls_designer.designer_id,
                      polls_designer.name,
                      polls_designer.email,
                      polls_designer.phone,
                      polls_designer.role,
                      polls_design_designers.design_id
               FROM polls_designer
                        JOIN polls_design_designers
                             ON polls_designer.designer_id = polls_design_designers.designer_id) des
              ON polls_design.design_id = des.design_id
ORDER BY polls_design.status DESC, des.name;

alter table join_designer_des
    owner to hseezkivmyedbs;

