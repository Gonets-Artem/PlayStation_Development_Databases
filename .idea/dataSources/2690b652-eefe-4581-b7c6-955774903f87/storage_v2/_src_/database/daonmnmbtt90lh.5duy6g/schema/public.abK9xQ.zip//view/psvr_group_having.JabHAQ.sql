create view psvr_group_having(type_display, avg_viewing_angle) as
SELECT polls_psvr.type_display,
       avg(polls_psvr.viewing_angle) AS avg_viewing_angle
FROM polls_psvr
GROUP BY polls_psvr.type_display
HAVING avg(polls_psvr.viewing_angle) > 105::double precision
ORDER BY polls_psvr.type_display;

alter table psvr_group_having
    owner to hseezkivmyedbs;

