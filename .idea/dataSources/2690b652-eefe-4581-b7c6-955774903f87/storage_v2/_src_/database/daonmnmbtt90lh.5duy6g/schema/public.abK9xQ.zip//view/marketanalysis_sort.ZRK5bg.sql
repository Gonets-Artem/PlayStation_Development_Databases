create view marketanalysis_sort(market_analysis_id, quality, predicted_price, potential) as
SELECT polls_marketanalysis.market_analysis_id,
       polls_marketanalysis.quality,
       polls_marketanalysis.predicted_price,
       polls_marketanalysis.potential
FROM polls_marketanalysis
ORDER BY polls_marketanalysis.quality DESC, polls_marketanalysis.predicted_price;

alter table marketanalysis_sort
    owner to hseezkivmyedbs;

