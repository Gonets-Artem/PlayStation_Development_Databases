create view prmanager_group(advertising_department_id, count) as
SELECT polls_prmanager.advertising_department_id,
       count(polls_prmanager.name) AS count
FROM polls_prmanager
GROUP BY polls_prmanager.advertising_department_id
ORDER BY (count(polls_prmanager.name)) DESC, polls_prmanager.advertising_department_id;

alter table prmanager_group
    owner to hseezkivmyedbs;

