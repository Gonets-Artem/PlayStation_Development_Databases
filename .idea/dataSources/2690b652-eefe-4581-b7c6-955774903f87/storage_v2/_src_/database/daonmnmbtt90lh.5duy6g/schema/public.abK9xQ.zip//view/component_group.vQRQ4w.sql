create view component_group(storage_room_id, count) as
SELECT polls_component.storage_room_id,
       count(polls_component.name) AS count
FROM polls_component
GROUP BY polls_component.storage_room_id
ORDER BY (count(polls_component.name)) DESC, polls_component.storage_room_id;

alter table component_group
    owner to hseezkivmyedbs;

