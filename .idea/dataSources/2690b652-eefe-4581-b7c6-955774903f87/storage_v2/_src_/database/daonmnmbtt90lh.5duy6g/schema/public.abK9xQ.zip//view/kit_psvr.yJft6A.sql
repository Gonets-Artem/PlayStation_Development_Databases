create view kit_psvr(kit_id, name, date, console_id, psvr_id) as
SELECT polls_kit.kit_id,
       polls_kit.name,
       polls_kit.date,
       polls_kit.console_id,
       polls_kit.psvr_id
FROM polls_kit
WHERE polls_kit.dualshock_id IS NULL
  AND polls_kit.psvr_id IS NOT NULL
ORDER BY polls_kit.date;

alter table kit_psvr
    owner to hseezkivmyedbs;

