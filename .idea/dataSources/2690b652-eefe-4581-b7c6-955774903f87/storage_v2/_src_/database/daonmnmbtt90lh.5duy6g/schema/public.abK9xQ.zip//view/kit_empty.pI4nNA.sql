create view kit_empty(kit_id, name, date, console_id) as
SELECT polls_kit.kit_id,
       polls_kit.name,
       polls_kit.date,
       polls_kit.console_id
FROM polls_kit
WHERE polls_kit.dualshock_id IS NULL
  AND polls_kit.psvr_id IS NULL
ORDER BY polls_kit.date;

alter table kit_empty
    owner to hseezkivmyedbs;

