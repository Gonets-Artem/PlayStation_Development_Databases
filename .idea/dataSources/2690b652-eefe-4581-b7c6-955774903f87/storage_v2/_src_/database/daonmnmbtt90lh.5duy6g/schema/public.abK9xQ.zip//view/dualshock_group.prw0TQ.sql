create view dualshock_group(compatibility, max_weight, max_action_radius, max_battery_power) as
SELECT polls_dualshock.compatibility,
       max(polls_dualshock.weight)        AS max_weight,
       max(polls_dualshock.action_radius) AS max_action_radius,
       max(polls_dualshock.battery_power) AS max_battery_power
FROM polls_dualshock
WHERE polls_dualshock.action_radius >= 4.5::double precision
  AND polls_dualshock.action_radius <= 6.5::double precision
GROUP BY polls_dualshock.compatibility
ORDER BY (max(polls_dualshock.weight)) DESC, (max(polls_dualshock.action_radius)) DESC,
         (max(polls_dualshock.battery_power)) DESC;

alter table dualshock_group
    owner to hseezkivmyedbs;

