create view equipment_group(plant_id, count) as
SELECT polls_equipment.plant_id,
       count(polls_equipment.name) AS count
FROM polls_equipment
GROUP BY polls_equipment.plant_id
ORDER BY (count(polls_equipment.name)) DESC, polls_equipment.plant_id;

alter table equipment_group
    owner to hseezkivmyedbs;

