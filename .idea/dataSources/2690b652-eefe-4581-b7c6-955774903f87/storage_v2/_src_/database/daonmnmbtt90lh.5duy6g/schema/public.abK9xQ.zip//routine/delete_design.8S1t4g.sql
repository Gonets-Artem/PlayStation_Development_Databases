create function delete_design() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_design_designers where design_id=old.design_id;
    return old;
end;
$$;

alter function delete_design() owner to hseezkivmyedbs;

