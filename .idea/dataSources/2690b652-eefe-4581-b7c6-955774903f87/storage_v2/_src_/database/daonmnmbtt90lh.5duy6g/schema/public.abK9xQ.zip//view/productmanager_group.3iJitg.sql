create view productmanager_group(advertising_department_id, count) as
SELECT polls_productmanager.advertising_department_id,
       count(polls_productmanager.name) AS count
FROM polls_productmanager
GROUP BY polls_productmanager.advertising_department_id
ORDER BY (count(polls_productmanager.name)) DESC, polls_productmanager.advertising_department_id;

alter table productmanager_group
    owner to hseezkivmyedbs;

