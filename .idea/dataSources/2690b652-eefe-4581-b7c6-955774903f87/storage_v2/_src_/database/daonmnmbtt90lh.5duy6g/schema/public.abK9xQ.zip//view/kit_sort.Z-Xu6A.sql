create view kit_sort(kit_id, name, date, psvr_id, dualshock_id) as
SELECT polls_kit.kit_id,
       polls_kit.name,
       polls_kit.date,
       polls_kit.psvr_id,
       polls_kit.dualshock_id
FROM polls_kit
ORDER BY polls_kit.date;

alter table kit_sort
    owner to hseezkivmyedbs;

