create function delete_supplier() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_supplier_components where supplier_id=old.supplier_id;
    return old;
end;
$$;

alter function delete_supplier() owner to hseezkivmyedbs;

