create view equipmentcondition_group
            (service_ability, avg_noise_level, avg_temperature, avg_wear_level, avg_errors_number) as
SELECT polls_equipmentcondition.service_ability,
       round(avg(polls_equipmentcondition.noise_level))   AS avg_noise_level,
       round(avg(polls_equipmentcondition.temperature))   AS avg_temperature,
       round(avg(polls_equipmentcondition.wear_level))    AS avg_wear_level,
       round(avg(polls_equipmentcondition.errors_number)) AS avg_errors_number
FROM polls_equipmentcondition
GROUP BY polls_equipmentcondition.service_ability
ORDER BY polls_equipmentcondition.service_ability DESC;

alter table equipmentcondition_group
    owner to hseezkivmyedbs;

