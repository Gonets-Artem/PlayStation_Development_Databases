create view join_plant
            (plant_id, plant_name, plant_location, specifications, storage_room_location, capacity, component_name,
             component_description, equipment_name, equipment_description, employee_name, role, email, phone)
as
SELECT plant_eq_em.plant_id,
       plant_eq_em.plant_name,
       plant_eq_em.plant_location,
       plant_eq_em.specifications,
       plant_eq_em.storage_room_location,
       plant_eq_em.capacity,
       plant_eq_em.component_name,
       plant_eq_em.component_description,
       plant_eq_em.equipment_name,
       plant_eq_em.equipment_description,
       polls_employee.name AS employee_name,
       polls_employee.role,
       polls_employee.email,
       polls_employee.phone
FROM polls_employee
         JOIN (SELECT plant_eq.plant_id,
                      plant_eq.plant_name,
                      plant_eq.plant_location,
                      plant_eq.specifications,
                      plant_eq.storage_room_location,
                      plant_eq.capacity,
                      plant_eq.component_name,
                      plant_eq.component_description,
                      plant_eq.equipment_name,
                      plant_eq.equipment_description,
                      polls_employee_equipments.employee_id
               FROM polls_employee_equipments
                        JOIN (SELECT plant_sr_comp.plant_id,
                                     plant_sr_comp.plant_name,
                                     plant_sr_comp.plant_location,
                                     plant_sr_comp.specifications,
                                     plant_sr_comp.storage_room_location,
                                     plant_sr_comp.capacity,
                                     plant_sr_comp.component_name,
                                     plant_sr_comp.description   AS component_description,
                                     polls_equipment.name        AS equipment_name,
                                     polls_equipment.description AS equipment_description,
                                     polls_equipment.equipment_id
                              FROM polls_equipment
                                       JOIN (SELECT plant_sr.plant_id,
                                                    plant_sr.name        AS plant_name,
                                                    plant_sr.plant_location,
                                                    plant_sr.specifications,
                                                    plant_sr.storage_room_location,
                                                    plant_sr.capacity,
                                                    polls_component.name AS component_name,
                                                    polls_component.description
                                             FROM polls_component
                                                      JOIN (SELECT polls_plant.plant_id,
                                                                   polls_plant.name,
                                                                   polls_plant.location       AS plant_location,
                                                                   polls_plant.specifications,
                                                                   polls_storageroom.location AS storage_room_location,
                                                                   polls_storageroom.capacity,
                                                                   polls_storageroom.storage_room_id
                                                            FROM polls_plant
                                                                     JOIN polls_storageroom ON polls_plant.plant_id = polls_storageroom.plant_id) plant_sr
                                                           ON polls_component.storage_room_id = plant_sr.storage_room_id) plant_sr_comp
                                            ON polls_equipment.plant_id = plant_sr_comp.plant_id) plant_eq
                             ON polls_employee_equipments.equipment_id = plant_eq.equipment_id) plant_eq_em
              ON polls_employee.employee_id = plant_eq_em.employee_id;

alter table join_plant
    owner to hseezkivmyedbs;

