create view consoles_rom(console_id, name, date, rom, ram, weight) as
SELECT polls_console.console_id,
       polls_console.name,
       polls_console.date,
       polls_console.rom,
       polls_console.ram,
       polls_console.weight
FROM polls_console
ORDER BY polls_console.rom DESC, polls_console.name;

alter table consoles_rom
    owner to hseezkivmyedbs;

