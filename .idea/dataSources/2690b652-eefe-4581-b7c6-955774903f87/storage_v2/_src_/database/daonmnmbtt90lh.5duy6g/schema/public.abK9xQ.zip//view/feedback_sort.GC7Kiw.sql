create view feedback_sort(feedback_id, evaluation, comment) as
SELECT polls_feedback.feedback_id,
       polls_feedback.evaluation,
       polls_feedback.comment
FROM polls_feedback
ORDER BY polls_feedback.evaluation DESC;

alter table feedback_sort
    owner to hseezkivmyedbs;

