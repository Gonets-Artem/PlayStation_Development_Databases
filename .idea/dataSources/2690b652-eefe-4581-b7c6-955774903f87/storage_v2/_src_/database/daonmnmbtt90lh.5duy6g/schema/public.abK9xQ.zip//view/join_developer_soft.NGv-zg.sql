create view join_developer_soft(developer_name, email, phone, role, type, version, status) as
SELECT dev.name AS developer_name,
       dev.email,
       dev.phone,
       dev.role,
       polls_software.type,
       polls_software.version,
       polls_software.status
FROM polls_software
         JOIN (SELECT polls_developer.developer_id,
                      polls_developer.name,
                      polls_developer.email,
                      polls_developer.phone,
                      polls_developer.role,
                      polls_software_developers.software_id
               FROM polls_developer
                        JOIN polls_software_developers
                             ON polls_developer.developer_id = polls_software_developers.developer_id) dev
              ON polls_software.software_id = dev.software_id
ORDER BY polls_software.status DESC, dev.name;

alter table join_developer_soft
    owner to hseezkivmyedbs;

