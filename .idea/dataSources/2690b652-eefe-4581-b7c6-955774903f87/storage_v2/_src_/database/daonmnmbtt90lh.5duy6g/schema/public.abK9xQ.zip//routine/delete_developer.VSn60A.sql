create function delete_developer() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_software_developers where developer_id=old.developer_id;
    return old;
end;
$$;

alter function delete_developer() owner to hseezkivmyedbs;

