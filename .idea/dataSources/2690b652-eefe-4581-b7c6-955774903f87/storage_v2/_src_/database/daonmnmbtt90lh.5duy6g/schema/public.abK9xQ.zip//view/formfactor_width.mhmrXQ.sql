create view formfactor_width(form_factor_id, name, form, width, height, weight, depth) as
SELECT polls_formfactor.form_factor_id,
       polls_formfactor.name,
       polls_formfactor.form,
       polls_formfactor.width,
       polls_formfactor.height,
       polls_formfactor.weight,
       polls_formfactor.depth
FROM polls_formfactor
ORDER BY polls_formfactor.width DESC, polls_formfactor.name;

alter table formfactor_width
    owner to hseezkivmyedbs;

