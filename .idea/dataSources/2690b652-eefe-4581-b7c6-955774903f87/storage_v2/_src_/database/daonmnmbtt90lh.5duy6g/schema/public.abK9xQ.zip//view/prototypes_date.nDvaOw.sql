create view prototypes_date (prototype_id, name, date, type_storage_device, ssd_type, specifications) as
SELECT polls_prototype.prototype_id,
       polls_prototype.name,
       polls_prototype.date,
       polls_prototype.type_storage_device,
       polls_prototype.ssd_type,
       polls_prototype.specifications
FROM polls_prototype
ORDER BY polls_prototype.date, polls_prototype.name;

alter table prototypes_date
    owner to hseezkivmyedbs;

