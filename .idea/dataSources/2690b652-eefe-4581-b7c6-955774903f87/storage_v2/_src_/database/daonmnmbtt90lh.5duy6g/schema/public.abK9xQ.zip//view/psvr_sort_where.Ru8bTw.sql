create view psvr_sort_where(ps_vr_id, country, type_display, diagonal, viewing_angle) as
SELECT polls_psvr.ps_vr_id,
       polls_psvr.country,
       polls_psvr.type_display,
       polls_psvr.diagonal,
       polls_psvr.viewing_angle
FROM polls_psvr
WHERE polls_psvr.permission::text = '3840x2160'::text
ORDER BY polls_psvr.diagonal DESC, polls_psvr.viewing_angle DESC;

alter table psvr_sort_where
    owner to hseezkivmyedbs;

