create view storageroom_group(plant_id, general_capacity, count) as
SELECT polls_storageroom.plant_id,
       sum(polls_storageroom.capacity)   AS general_capacity,
       count(polls_storageroom.location) AS count
FROM polls_storageroom
GROUP BY polls_storageroom.plant_id
ORDER BY (sum(polls_storageroom.capacity)) DESC, (count(polls_storageroom.location)) DESC;

alter table storageroom_group
    owner to hseezkivmyedbs;

