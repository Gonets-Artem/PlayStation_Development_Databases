create view join_full_kit
            (kit_id, kit_name, date_kit, design_name, style, colour, console_name, dualshock_id, psvr_id, contacts,
             avg_evaluation, plant_id, location, specifications)
as
SELECT kit_feed_des_con.kit_id,
       kit_feed_des_con.kit_name,
       kit_feed_des_con.date_kit,
       kit_feed_des_con.design_name,
       kit_feed_des_con.style,
       kit_feed_des_con.colour,
       kit_feed_des_con.console_name,
       kit_feed_des_con.dualshock_id,
       kit_feed_des_con.psvr_id,
       kit_feed_des_con.contacts,
       kit_feed_des_con.avg_evaluation,
       polls_plant.plant_id,
       polls_plant.location,
       polls_plant.specifications
FROM polls_plant
         JOIN (SELECT kit_feed_des.kit_id,
                      kit_feed_des.kit_name,
                      kit_feed_des.date  AS date_kit,
                      kit_feed_des.design_name,
                      kit_feed_des.style,
                      kit_feed_des.colour,
                      polls_console.name AS console_name,
                      kit_feed_des.dualshock_id,
                      kit_feed_des.psvr_id,
                      kit_feed_des.contacts,
                      kit_feed_des.avg_evaluation,
                      kit_feed_des.plant_id
               FROM polls_console
                        JOIN (SELECT kit_feed.kit_id,
                                     kit_feed.name     AS kit_name,
                                     kit_feed.date,
                                     polls_design.name AS design_name,
                                     polls_design.style,
                                     polls_design.colour,
                                     kit_feed.console_id,
                                     kit_feed.dualshock_id,
                                     kit_feed.psvr_id,
                                     kit_feed.plant_id,
                                     kit_feed.contacts,
                                     kit_feed.avg_evaluation
                              FROM polls_design
                                       JOIN (SELECT polls_kit.kit_id,
                                                    polls_kit.name,
                                                    polls_kit.date,
                                                    polls_kit.console_id,
                                                    polls_kit.design_id,
                                                    polls_kit.dualshock_id,
                                                    polls_kit.plant_id,
                                                    polls_kit.psvr_id,
                                                    feedprm_pr_adv.contacts,
                                                    feedprm_pr_adv.avg_evaluation
                                             FROM polls_kit
                                                      JOIN (SELECT feedprm_pr.avg_evaluation,
                                                                   feedprm_pr.advertising_department_id,
                                                                   polls_advertisingdepartment.contacts
                                                            FROM polls_advertisingdepartment
                                                                     JOIN (SELECT round(avg(feedprm.evaluation), 1) AS avg_evaluation,
                                                                                  polls_prmanager.advertising_department_id
                                                                           FROM polls_prmanager
                                                                                    JOIN (SELECT polls_feedback.evaluation,
                                                                                                 polls_prmanager_feedbacks.prmanager_id
                                                                                          FROM polls_feedback
                                                                                                   JOIN polls_prmanager_feedbacks
                                                                                                        ON polls_feedback.feedback_id = polls_prmanager_feedbacks.feedback_id) feedprm
                                                                                         ON polls_prmanager.pr_manager_id = feedprm.prmanager_id
                                                                           GROUP BY polls_prmanager.advertising_department_id) feedprm_pr
                                                                          ON polls_advertisingdepartment.advertising_department_id =
                                                                             feedprm_pr.advertising_department_id) feedprm_pr_adv
                                                           ON polls_kit.advertising_department_id =
                                                              feedprm_pr_adv.advertising_department_id) kit_feed
                                            ON polls_design.design_id = kit_feed.design_id) kit_feed_des
                             ON polls_console.console_id = kit_feed_des.console_id) kit_feed_des_con
              ON polls_plant.plant_id = kit_feed_des_con.plant_id;

alter table join_full_kit
    owner to hseezkivmyedbs;

