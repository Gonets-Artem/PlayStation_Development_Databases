create function delete_designer() returns trigger
    language plpgsql
as
$$
begin
    delete from polls_design_designers where designer_id=old.designer_id;
    return old;
end;
$$;

alter function delete_designer() owner to hseezkivmyedbs;

